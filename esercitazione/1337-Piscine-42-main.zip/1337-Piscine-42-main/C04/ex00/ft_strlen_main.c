#include <stdio.h>
int	ft_strlen(char *str);
int main (void)
{
	printf("%i", ft_strlen("854dsjfksdlk"));
}
