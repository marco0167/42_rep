int	ft_mod(int a, int b)
{
	return (a % b);
}
