int	ft_div(int a, int b)
{
	 return (a / b);
}	
